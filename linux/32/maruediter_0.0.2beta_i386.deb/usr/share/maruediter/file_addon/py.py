def get_info(argv):
    if argv == "addon_var":
        return "b0.0.1"
    elif argv == "template_var":
        return "b0.0.1"
    elif argv == "__built_in__":
        return 0
    elif argv == "type":
        return ".py"
    elif argv == "type_ex":
        return "python script file"
    else:
        return 0
def file_new(open_pas):
    pass
def file_open(open_pas, ofps, window):
    pass
def file_save(open_pas, master):
    pass
def file_main(master):
    pass
