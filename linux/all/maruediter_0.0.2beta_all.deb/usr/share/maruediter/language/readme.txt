##########################################
# Marusoftware Maruediter Language Files #
#                                        # 
#        2020 - Marusoftware             #
##########################################

This directory include Language Files for
Marusoftware Maruediter.
This is only for Maruediter.
Do not copy these files.

Now we serve these languages:
 ja-JP : Japanese
 en-US : English(US)
 af : Afrikaans
 zh* : Chinese(Hant and Hans)

If you want another one, please contact
here.

Mail: marusoftware@outlook.jp
